# Signal Bot

Telegram으로 저점 롱 / 고점 숏 신호를 보내는 봇입니다.
